
export default function UserProfile({ params }: { params: { username: string } }) {
  // Simulate fetching profile with donation link
  const donationLink = "https://buymeacoffee.com/exampleuser"; // Replace with Supabase logic

  return (
    <div className="min-h-screen p-6 text-center space-y-4">
      <h1 className="text-3xl font-bold">@{params.username}</h1>

      {donationLink && (
        <a
          href={donationLink}
          target="_blank"
          rel="noopener noreferrer"
          className="inline-block px-5 py-3 bg-yellow-400 text-black rounded-xl hover:bg-yellow-300 transition"
        >
          ☕ Buy Me a Coffee
        </a>
      )}
    </div>
  );
}
